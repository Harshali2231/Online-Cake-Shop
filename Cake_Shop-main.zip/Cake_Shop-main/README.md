# Cake_Shop

Online Cake Order is a web based application which enable customers to order cakes through Online. The internet users are increasing rapidly , the company has introduce Online cake ordering system for getting the orders from customers. This application not only improves customers experiences but also eases the workload on the employees of the cake shop.

Customer Modules:-

1. Registration Module
2. Login Module
3. Homepage Module
4. Cake Customization Module
5. Cake recipe Module
6. Add to cart Module
7. Shipping Module
8. Payment Module
9. Order Confirmation Module
